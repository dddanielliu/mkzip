#include <fstream>
#include <iostream>
// #include "vec3.h"
#include "bonus.h"
#include "normal.h"
#include "red.h"
#include "shading.h"
#include "skybox.h"
#include <vector>
using namespace std;

int main()
{
    int width = 200;
    int height = 100;

    // fstream file;
    // file.open("ray.ppm", ios::out);

    // file << "P3\n" << width << " " << height << "\n255\n";
    // for (int j = height - 1; j >= 0; j--)
    // {
    //     for (int i = 0; i < width; i++)
    //     {
    //         float r = float(i) / float(width);
    //         float g = float(j) / float(height);
    //         float b = 0.2;

    //         file << int(r * 255) << " " << int(g * 255) << " " << int(b *
    //         255)
    //              << "\n";
    //     }
    // }

    vec3 center(0, 0, -1);
    vec3 light_source(1, 0.7, 0);
    vec3 bg_color(0.8, 0.6, 1.0);

    Skybox sky("skybox", bg_color, width, height);
    sky.draw();

    Red red("red", bg_color, center, light_source, width, height);
    red.draw();

    Normal normal("normal", bg_color, center, light_source, width, height);
    normal.draw();

    Shading shading("shading", bg_color, center, light_source, width, height);
    shading.draw();

    vector<light_src> multi_light_source = {
        {vec3(1, 0.7, 0), vec3(1, 0, 0)},
        {vec3(-1, -0.08, -0.23), vec3(0, 0, 1)},
    };
    Bonus bonus("bonus", bg_color, center, multi_light_source, width, height);
    bonus.draw();

    return 0;
}
