#ifndef BASE_DRAW_H
#define BASE_DRAW_H

#include "ray.h"
#include "vec3.h"
#include <algorithm>
#include <fstream>
#include <string>

class BaseDraw
{
  public:
    BaseDraw(std::string name, const int width, const int height)
        : _name(name), _width(width), _height(height) {};

    virtual vec3 color(const ray &r) = 0;
    virtual ~BaseDraw() = default;

    void draw()
    {
        std::fstream file;
        file.open(_name + ".ppm", std::ios::out);
        vec3 lower_left_corner(-2.0, -1.0, -1.0);
        vec3 origin(0.0, 0.0, 0.0);
        vec3 horizontal(4.0, 0.0, 0.0);
        vec3 vertical(0.0, 2.0, 0.0);

        file << "P3\n" << _width << " " << _height << "\n255\n";
        for (int j = _height - 1; j >= 0; j--)
        {
            for (int i = 0; i < _width; i++)
            {
                float u = float(i) / float(_width);
                float v = float(j) / float(_height);
                vec3 uvcenter =
                    lower_left_corner + u * horizontal + v * vertical;
                ray r(origin, uvcenter - origin);
                vec3 col = color(r);
                file << int(col[0] * 255) << " " << int(col[1] * 255) << " "
                     << int(col[2] * 255) << "\n";
            }
        }
    }

  private:
    std::string _name;
    int _width;
    int _height;
};

#endif // !BASE_DRAW_H
