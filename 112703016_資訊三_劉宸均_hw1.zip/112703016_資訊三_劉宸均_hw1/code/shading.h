#ifndef SHADING_H
#define SHADING_H

#include "base_draw.h"

#include "ray.h"
#include "vec3.h"
#include <algorithm>
#include <fstream>

class Shading : public BaseDraw
{
  public:
    Shading(std::string name, const vec3 &bg_color, const vec3 &center,
            const vec3 &light_source, int width = 200, int height = 100)
        : BaseDraw(name, width, height), _center(center),
          _light_source(light_source), _bg_color(bg_color) {};

    float hit_sphere(const vec3 &center, float radius, const ray &r)
    {
        vec3 d = unit_vector(r.direction());

        float b = 2.0 * dot(d, r.origin() - center);
        float e =
            dot(r.origin() - center, r.origin() - center) - radius * radius;

        float discriminant = b * b - 4.0 * e;

        if (discriminant < 0)
        {
            return -1.0;
        }
        else
        {
            float t = (-b - sqrt(discriminant)) / 2.0;
            return t;
        }
    }

    vec3 color(const ray &r)
    {
        float t = hit_sphere(_center, 0.5, r);
        if (t > 0.0)
        {
            vec3 N = unit_vector(r.point_at_parameter(t) - _center);
            vec3 L = unit_vector(_light_source - r.point_at_parameter(t));
            vec3 I = vec3(1, 1, 1); // light intensity
            return I * std::max(dot(N, L), 0.0f);
        }
        vec3 unit_direction = unit_vector(r.direction());
        t = 0.5 * (unit_direction.y() + 1.0);
        return (1.0 - t) * vec3(1.0, 1.0, 1.0) + t * _bg_color;
    }

  protected:
    vec3 _center;       // sphere center
    vec3 _light_source; // light source position
    vec3 _bg_color;     // background color
};

#endif // !SHADING_H
