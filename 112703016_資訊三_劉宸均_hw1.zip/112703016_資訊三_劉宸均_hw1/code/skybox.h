#ifndef SKYBOX_H
#define SKYBOX_H

#include "base_draw.h"

#include "ray.h"
#include "vec3.h"
#include <algorithm>
#include <fstream>

class Skybox : public BaseDraw
{
  public:
    Skybox(std::string name, const vec3 &bg_color, int width = 200,
           int height = 100)
        : BaseDraw(name, width, height), _bg_color(bg_color) {};

    vec3 color(const ray &r) override
    {
        vec3 unit_direction = unit_vector(r.direction());
        float t = 0.5 * (unit_direction.y() + 1.0);
        return (1.0 - t) * vec3(1, 1, 1) + t * vec3(_bg_color);
    }

  protected:
    vec3 _bg_color; // background color
};

#endif // !SKYBOX_H
