#ifndef BONUS_H
#define BONUS_H

#include "base_draw.h"
#include "ray.h"
#include "vec3.h"
#include <algorithm>
#include <fstream>
#include <vector>

struct light_src
{
    vec3 pos;       // light source position
    vec3 intensity; // light source intensity (color)
};

class Bonus : public BaseDraw
{
  public:
    Bonus(std::string name, const vec3 &bg_color, const vec3 &center,
          const std::vector<light_src> &light_sources, int width = 200,
          int height = 100)
        : BaseDraw(name, width, height), _center(center),
          _light_sources(light_sources), _bg_color(bg_color) {};

    float hit_sphere(const vec3 &center, float radius, const ray &r)
    {
        vec3 d = unit_vector(r.direction());

        float b = 2.0 * dot(d, r.origin() - center);
        float e =
            dot(r.origin() - center, r.origin() - center) - radius * radius;

        float discriminant = b * b - 4.0 * e;

        if (discriminant < 0)
        {
            return -1.0;
        }
        else
        {
            float t = (-b - sqrt(discriminant)) / 2.0;
            return t;
        }
    }

    vec3 color(const ray &r)
    {
        float t = hit_sphere(_center, 0.5, r);
        if (t > 0.0)
        {
            vec3 final_color(0, 0, 0);
            for (auto &it : _light_sources)
            {
                vec3 N = unit_vector(r.point_at_parameter(t) - _center);
                vec3 L = unit_vector(it.pos - r.point_at_parameter(t));
                final_color += it.intensity * std::max(dot(N, L), 0.0f);
            }
            // mask out of bound
            for (int i = 0; i < 3; i++)
                final_color[i] = std::min(final_color[i], 1.0f);
            return final_color;
        }
        vec3 unit_direction = unit_vector(r.direction());
        t = 0.5 * (unit_direction.y() + 1.0);
        return (1.0 - t) * vec3(1.0, 1.0, 1.0) + t * _bg_color;
    }

  protected:
    vec3 _center;                          // sphere center
    std::vector<light_src> _light_sources; // light source
    vec3 _bg_color;                        // background color
};

#endif // !BONUS_H
