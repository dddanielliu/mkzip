#ifndef RED_H
#define RED_H

#include "base_draw.h"

#include "ray.h"
#include "vec3.h"
#include <algorithm>
#include <fstream>

class Red : public BaseDraw
{
  public:
    Red(std::string name, const vec3 &bg_color, const vec3 &center,
        const vec3 &light_source, int width = 200, int height = 100)
        : BaseDraw(name, width, height), _center(center),
          _bg_color(bg_color) {};

    bool hit_sphere(const vec3 &center, float radius, const ray &r)
    {
        vec3 d = unit_vector(r.direction());

        float b = 2.0 * dot(d, r.origin() - center);
        float e =
            dot(r.origin() - center, r.origin() - center) - radius * radius;

        float discriminant = b * b - 4.0 * e;

        return (discriminant > 0);
    }

    vec3 color(const ray &r)
    {
        if (hit_sphere(_center, 0.5, r))
        {
            return vec3(1, 0, 0);
        }
        vec3 unit_direction = unit_vector(r.direction());
        float t = 0.5 * (unit_direction.y() + 1.0);
        return (1.0 - t) * vec3(1.0, 1.0, 1.0) + t * vec3(_bg_color);
    }

  protected:
    vec3 _center;   // sphere center
    vec3 _bg_color; // background color
};

#endif // !RED_H
